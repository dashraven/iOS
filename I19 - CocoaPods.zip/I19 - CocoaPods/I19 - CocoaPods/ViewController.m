//
//  ViewController.m
//  I19 - CocoaPods
//
//  Created by Formando Web Mobile on 28/03/16.
//  Copyright © 2016 Formando Web Mobile. All rights reserved.
//

#import "ViewController.h"
#import <AFNetworking/AFNetworking.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITableView *table1;
@property (weak, nonatomic) IBOutlet UIView *tableCell;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:@"http://jsonplaceholder.typicode.com/posts/"
      parameters:nil
        progress:nil
         success:^(NSURLSessionDataTask *task, id responseObject) {
             
             NSLog(@"YAY CORREU BEM!!!!");
             NSLog(@"%@", responseObject);
             
             
             
         } failure:^(NSURLSessionDataTask *task, NSError *error){
         
             NSLog(@"NAY CORREU MAL!!!!");
             NSLog(@"%@", error);
             
         }
        ];

}




@end
