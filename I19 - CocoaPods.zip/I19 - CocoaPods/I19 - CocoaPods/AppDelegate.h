//
//  AppDelegate.h
//  I19 - CocoaPods
//
//  Created by Formando Web Mobile on 28/03/16.
//  Copyright © 2016 Formando Web Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

